<!DOCTYPE html>
<html lang="en">
<head>
  <title>Project</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
   <link href="project.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
<!-- *******************rickshaw  ******************************-->
<link type="text/css" rel="stylesheet" href="rickshaw.min.css">
  <script src="vendor/d3.min.js"></script> 
  <script src="vendor/d3.layout.min.js"></script> 
  <script src="rickshaw.min.js"></script> 
</head>
  <body>  
           
    <nav class="navbar navbar-default" >
      <div class="container-fluid"  >
          <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
          <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
          <li class="active" > <a href="http://localhost/www/project/project1.php">Project </a>
          <li><a href="contact.html" id = "contact">Contact</a></li> 
          </li>
        </div>                
    </nav> 
<div class  = "zero" align = "center" >
  <img class="animated swing"  id= "logo1" src= "mylogo.jpg">
</div> <br><br>

<div class="container">
	<div class = table1>
		<a href="#demo" class="btn btn-info" data-toggle="collapse">Click to find info by Countries</a>  <br> <br>
  	<div id="demo" class="collapse">
			<table class = "table table-striped table-bordered" id = "countries_table">
				<tr>
       		<th>Country</th>
          <th>CDN</th>
         	<th>P2P</th>
       		<th>PERCENTAGE</th>
       		<th>TOTAL</th>       					
      	</tr>
      </table>
   	</div>  		
	</div>
</div>

<div class="container">
  <div class = table2>
    <a href="#demo1" class="btn btn-info" data-toggle="collapse">Click to find info by ISPs </a>  <br> <br>
      <div id="demo1" class="collapse">
        <table class = "table table-striped table-bordered" id = "isp_table">
        <tr>
          <th>ISP</th>
          <th>CDN</th>
          <th>P2P</th>
          <th>PERCENTAGE</th>
          <th>TOTAL</th>                 
        </tr>
      </table>
    </div>      
  </div>
</div>

<div class="container">
  <a href="#demo2" class="btn btn-info" data-toggle="collapse"> Click to find info by Platform usage </a>   <br> <br>
    <div id="demo2" class="collapse">
      <table class = "table table-striped table-bordered" id = "platform_table">
        <tr>
          <th>PLATFORM</th>
          <th>CDN</th>
          <th>P2P</th>
          <th>TOTAL</th>
          <th>UPLOAD</th> 
          <th>PERCENTAGE</th>
          <th>VIEWERS</th>
          <th>MAX.VIEWERS</th>
          <th>AVG.VIEWERS</th>
          <th>TRAFFIC PERCENTAGE</th>                  
          <th>LIVE</th>
        </tr>
      </table>
    </div>      
  </div>
</div> 

<div class="container">
  <a href="#demo3" class="btn btn-info" data-toggle="collapse"> Click to find info by Streams </a>   <br> <br>
    <div id="demo3" class="collapse">
      <table class = "table table-striped table-bordered" id = "streams_table">
        <tr>
          <th>CDN</th>
          <th>P2P</th>
          <th>TOTAL</th>
          <th>PERCENTAGE</th>
          <th>MANIFEST</th>
          <th>TRAFFIC PERCENTAGE </th>
          <th>MAX.VIEWERS</th>
          <th>AVERAGE VIEWERS </th>                  
          <th>LIVE</th>
        </tr>
      </table>
    </div>      
  </div>
</div> <br><br>

<div align="center"> <a href="#top"> <img src = "back_to_top.png" alt = Click to scroll back up> </img> </a> </div> 

    <footer>
      <div id="fifth" align="center">
        <div class="well well-sm">
          <a href="http://www.facebook.com" class="fa fa-facebook" target="_blank" > </a>
          <a href="https://www.twitter.com" class="fa fa-twitter" target="_blank"></a>
          <a href="http://www.googleplus.com" class="fa fa-google" target="_blank"> </a>
          <a href="http://www.linkedin.com" class="fa fa-linkedin" target="_blank"> </a>
          All rights reserved by me :)
        </div>
      </div>           
    </footer> 
  </body>
</html>

<script>
	$(document).ready(function(){
		$.getJSON("http://localhost/www/project/country.json", function(data){
      var countries_data ='';
      var nombreNotationScientifique10 = 'number.toExponential(10)';
			$.each (data, function(key,value){				
        countries_data += '<tr>';
        countries_data += '<td>'+ value.country + '</td>';
				countries_data += '<td>'+ parseFloat(value.cdn) + '</td>';
				countries_data += '<td>'+ parseFloat(value.p2p)+ '</td>';
				countries_data += '<td>'+ parseFloat(value.percentage) + '</td>';
				countries_data += '<td>'+ parseFloat(value.total) + '</td>'; 			
				countries_data += '</tr>';
				});
				$('#countries_table').append(countries_data);
			});
		});
</script>

<script>
  $(document).ready(function(){
    $.getJSON("http://localhost/www/project/isp.json", function(data){
      var isp_data ='';
      $.each (data, function(key,value){        
        isp_data += '<tr>';
        isp_data += '<td>'+ value.isp + '</td>';
        isp_data += '<td>'+ parseFloat(value.cdn) + '</td>';
        isp_data += '<td>'+ parseFloat(value.p2p)+ '</td>';
        isp_data += '<td>'+ parseFloat(value.percentage) + '</td>';
        isp_data += '<td>'+ parseFloat(value.total) + '</td>';        
        isp_data += '</tr>';
        });
        $('#isp_table').append(isp_data);
      });
    });
</script>

<script>
  $(document).ready(function(){
    $.getJSON("http://localhost/www/project/platform.json", function(data){
      var platform_data ='';
      $.each (data, function(key,value){        
        platform_data += '<tr>';
        platform_data += '<td>'+ value.platform + '</td>';
        platform_data += '<td>'+ parseFloat(value.cdn) + '</td>';
        platform_data += '<td>'+ parseFloat(value.p2p)+ '</td>';
        platform_data += '<td>'+ parseFloat(value.total) + '</td>';
        platform_data += '<td>'+ parseFloat(value.upload) + '</td>';
        platform_data += '<td>'+ parseFloat(value.percentage)+ '</td>';
        platform_data += '<td>'+ parseFloat(value.viewers) + '</td>';
        platform_data += '<td>'+ parseFloat(value.maxViewers) + '</td>';
        platform_data += '<td>'+ parseFloat(value.averageViewers) + '</td>';
        platform_data += '<td>'+ parseFloat(value.trafficPercentage) + '</td>';        
        platform_data += '<td>'+ value.live + '</td>';        
        platform_data += '</tr>';
        });
        $('#platform_table').append(platform_data);
      });
    });
</script>

<script>
  $(document).ready(function(){
    $.getJSON("http://localhost/www/project/streams.json", function(data){
      var streams_data ='';
      $.each (data, function(key,value){        
        streams_data += '<tr>';
        streams_data += '<td>'+ parseFloat(value.cdn) + '</td>';
        streams_data += '<td>'+ parseFloat(value.p2p)+ '</td>';
        streams_data += '<td>'+ parseFloat(value.total) + '</td>';
        streams_data += '<td>'+ parseFloat(value.percentage)+ '</td>';
        streams_data += '<td>'+ (value.manifest) + '</td>';
        streams_data += '<td>'+ parseFloat(value.trafficPercentage) + '</td>'; 
        streams_data += '<td>'+ parseFloat(value.maxViewers) + '</td>';
        streams_data += '<td>'+ parseFloat(value.averageViewers) + '</td>';
        streams_data += '<td>'+ (value.live) + '</td>'; 
               
        streams_data += '<td>'+ value.live + '</td>';        
        streams_data += '</tr>';
        });
        $('#streams_table').append(streams_data);
      });
    });
</script>